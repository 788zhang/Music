//
//  DetailViewController.h
//  AddressBook
//
//  Created by scjy on 15/12/3.
//  Copyright (c) 2015年 张鹏飞. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdressBookDateModel.h"
@interface DetailViewController : UIViewController
@property(nonatomic, retain) AdressBookDateModel *model;
@end
