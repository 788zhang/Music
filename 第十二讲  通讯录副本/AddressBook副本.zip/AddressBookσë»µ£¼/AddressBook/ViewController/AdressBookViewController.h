//
//  AdressBookViewController.h
//  AddressBook
//
//  Created by scjy on 15/12/3.
//  Copyright (c) 2015年 张鹏飞. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UpdateViewController.h"
#import "DetailView.h"
@interface AdressBookViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UpdateDelegate>
@end
